﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidBody;

    public float coins;
    public Text score;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidBody = gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidBody.AddForce(movement * speed * Time.deltaTime);
    }

    public void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == ("coins"))
        {
            Destroy(collision.gameObject);
            coins += 1;
            score.text = "Coins collected :" + coins;
            if(coins == 4)
            {
                SceneManager.LoadScene("WinScene");
            }
        }

        if(collision.gameObject.tag == ("hazard"))
        {
            SceneManager.LoadScene("LoseScene");
        }
    }
}
